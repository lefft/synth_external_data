
dat <- read.csv("9-12 Dropout Rate_2016_Feb_2_2017.csv");
dat02 <- read.csv("9-12 Dropout Rate_2016_Feb_2_2017.csv");
